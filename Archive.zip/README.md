# NotNews
Chrome extension that alerts you when you're on a fake news site.

Based on the work 'False, Misleading, Clickbait-y, and Satirical “News” Sources' by Melissa Zimdars. 
